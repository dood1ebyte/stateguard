"""
Repair result types: the complete output model of a repair session.

These dataclasses carry the full audit trail from a single
``ContractGuard.repair()`` invocation: what was found, what was attempted,
what was applied, and what remains unresolved.

Layer 1 — depends on:
  stateguard.core.errors.violations
  stateguard.core.errors.operations
  stateguard.core.models.config
  stateguard.logging.logger
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from stateguard.core.errors.operations import FieldOperation
from stateguard.core.errors.violations import ContractViolation
from stateguard.core.models.config import RepairMode
from stateguard.logging.logger import RepairLogEntry

if TYPE_CHECKING:
    from stateguard.core.explain import FieldDecision

__all__ = [
    "AmbiguousRepair",
    "RepairAttempt",
    "RepairResult",
    "RepairStatus",
    "ValidationResult",
]


# ---------------------------------------------------------------------------
# RepairStatus
# ---------------------------------------------------------------------------


class RepairStatus(StrEnum):
    """
    Terminal state of a repair session.

    Members
    -------
    SUCCESS:
        All violations were resolved.  ``RepairResult.repaired_output`` is
        a non-``None`` dict that passes full contract validation.
    PARTIAL:
        At least one violation was resolved, but some remain.
        ``RepairResult.repaired_output`` is set when
        ``RepairConfig.allow_partial_repair`` is ``True``; ``None`` when
        ``False``.
    FAILED:
        No violations were resolved (no applicable strategy, max attempts
        exhausted, no-progress detected, or regression introduced).
        ``RepairResult.repaired_output`` is always ``None``.
    ALREADY_VALID:
        The input data passed contract validation without any repair.
        The engine exits immediately; ``RepairResult.attempts`` is empty.
    AMBIGUOUS:
        A repair *was* found, but the evidence did not justify applying it
        unsupervised, and nothing else resolved the violation either.
        Distinct from ``FAILED``, which means no repair was found at all —
        the difference matters because an ambiguous result is actionable:
        ``RepairResult.ambiguous`` carries the candidates so a caller can
        re-prompt, a reviewer can choose, or Shadow Mode can display them.
    """

    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    ALREADY_VALID = "already_valid"
    AMBIGUOUS = "ambiguous"


# ---------------------------------------------------------------------------
# ValidationResult
# ---------------------------------------------------------------------------


@dataclass
class ValidationResult:
    """
    The output of a single validation pass (initial or revalidation).

    Produced by ``IContractAdapter.validate()`` — which uses the framework's
    own validator — and also by ``ContractValidator`` for initial violation
    analysis.

    Attributes
    ----------
    is_valid:
        ``True`` if the data satisfies the contract with no ERROR-severity
        violations.  WARNING violations do not set this to ``False``.
    violations:
        All violations detected in this pass.  Empty when ``is_valid`` is
        ``True``.
    raw_input:
        A snapshot of the data that was validated.  Normally a ``dict``, but
        typed ``Any`` because a payload whose root is not an object is
        reported rather than rejected at the boundary -- see
        ``stateguard.core.validator.root_structural_violation``.  Callers
        must not mutate this after construction.
    contract_id:
        The ``ContractSpec.contract_id`` against which this validation ran.
    validated_at:
        UTC timestamp, auto-set at construction.
    """

    is_valid: bool
    violations: list[ContractViolation]
    raw_input: Any
    contract_id: str
    validated_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# RepairAttempt
# ---------------------------------------------------------------------------


@dataclass
class RepairAttempt:
    """
    Records a single iteration of the repair loop.

    One ``RepairAttempt`` is created per strategy application.  If the engine
    runs three iterations it produces three ``RepairAttempt`` objects in
    ``RepairResult.attempts``.

    Attributes
    ----------
    attempt_number:
        1-indexed position of this attempt within the repair session.
    strategy_name:
        ``IRepairStrategy.name`` of the strategy that **acted** -- the one
        whose proposals reached ``applied_operations``.  An attempt may
        consult several: the engine walks applicable strategies in priority
        order until one has something it can apply, because otherwise a
        single uncertain rename would suppress a certain, schema-declared
        fill from a lower-priority strategy.  See ``considered_strategies``.
    considered_strategies:
        ``IRepairStrategy.name`` for every strategy consulted during this
        attempt, in the order they were tried.  ``strategy_name`` is always
        the last entry.  Without this the operation lists below could not be
        attributed: a proposal carried over from a passed-over strategy is
        indistinguishable from one made by the strategy that acted.
    violations_targeted:
        ``violation_id`` values of the violations this attempt addressed.
    proposed_operations:
        Every ``FieldOperation`` returned by ``propose()`` across **all**
        of ``considered_strategies``, not only ``strategy_name``.  Proposals
        from a passed-over strategy are kept because they were genuinely
        considered, and an abstention recorded by one must not be erased by
        whichever strategy ends up being selected.
    applied_operations:
        Subset of ``proposed_operations`` that ``TrustPolicy`` cleared for
        application *and* that actually changed the payload.  These always
        come from ``strategy_name``.
    rejected_operations:
        Subset of ``proposed_operations`` whose evidence was too weak to
        consider a repair at all, plus any that turned out to change nothing
        when applied.  May span ``considered_strategies``.
    abstained_operations:
        Subset of ``proposed_operations`` that ``TrustPolicy`` withheld -- a
        real repair was found, but not confidently enough to apply it
        unsupervised.  Without this an abstained operation appeared in
        neither list and the attempt read as "the strategy did nothing".
        Also collected across the whole run on ``RepairResult.ambiguous``.
        May span ``considered_strategies``.
    data_before:
        Deep copy of the working data dict *before* operations were applied.
    data_after:
        Deep copy of the working data dict *after* operations were applied.
    succeeded:
        ``True`` if revalidation after this attempt found no remaining
        ERROR-severity violations.
    kept:
        ``False`` when the engine discarded this attempt -- it made the
        violation set worse, or returned to a state already seen this run --
        and rolled back to the data it started from.  Its
        ``applied_operations`` were really applied to the engine's working
        copy, which is why they are recorded, but none of them reaches
        ``repaired_output`` or ``proposed_output``.  Only ever the last
        attempt.  Without this a discarded attempt was indistinguishable from
        a kept one, and an audit reading ``applied_operations`` reported
        repairs that are not in the payload.
    attempt_id:
        UUID4 string, auto-generated at construction.
    attempted_at:
        UTC timestamp, auto-set at construction.
    """

    # Required fields (no defaults)
    attempt_number: int
    strategy_name: str
    violations_targeted: list[str]
    proposed_operations: list[FieldOperation]
    applied_operations: list[FieldOperation]
    rejected_operations: list[FieldOperation]
    data_before: dict[str, Any]
    data_after: dict[str, Any]
    succeeded: bool

    # Optional / auto-generated fields
    abstained_operations: list[FieldOperation] = field(default_factory=list)
    considered_strategies: list[str] = field(default_factory=list)
    kept: bool = True
    attempt_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    attempted_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))


# ---------------------------------------------------------------------------
# AmbiguousRepair
# ---------------------------------------------------------------------------


@dataclass
class AmbiguousRepair:
    """
    A repair the engine found but declined to apply on its own authority.

    This is the abstain region of the trust model made visible.  A binary
    apply/reject threshold has to force every borderline case to one side, so
    it either guesses or silently drops the proposal — and the caller learns
    nothing either way.  Surfacing the candidates instead turns "I'm not sure"
    into something a caller can act on.

    Attributes
    ----------
    target_path:
        The field the proposed repair would have written.
    candidates:
        The operations considered, ranked by ``trust`` descending.  Usually
        one; more when several strategies proposed competing fixes.
    reason:
        Why none was applied — the trust achieved against the bar its risk
        tier requires.
    """

    target_path: str
    candidates: list[FieldOperation]
    reason: str

    @property
    def best(self) -> FieldOperation | None:
        """The highest-trust candidate, or ``None`` if there were none."""
        return self.candidates[0] if self.candidates else None


# ---------------------------------------------------------------------------
# RepairResult
# ---------------------------------------------------------------------------


@dataclass
class RepairResult:
    """
    The complete output of a ``ContractGuard.repair()`` invocation.

    Carries everything needed to understand what happened: the final status,
    the repaired data (if available), the full violation inventory, every
    repair attempt with its operations and before/after snapshots, and the
    structured audit log.

    Attributes
    ----------
    status:
        Terminal state of the repair session.
    original_input:
        Deep copy of the data exactly as received, before any repair --
        including the root-shape normalisation the engine applies to a
        JSON-string or single-element-sequence payload.  Typed ``Any``
        because that received value is not necessarily a ``dict``.
        Never mutated by the engine.
    initial_violations:
        All violations found in the first validation pass, before any repair.
    remaining_violations:
        Violations that were not resolved.  Empty on ``SUCCESS``.
        Non-empty on ``PARTIAL`` and ``FAILED``.
    attempts:
        Ordered list of repair attempts.  Empty on ``ALREADY_VALID``.
    repair_log:
        Structured audit log entries from the engine.
    contract_id:
        The ``ContractSpec.contract_id`` that was validated against.
    repaired_output:
        The repaired data, **committed**, or ``None``.

        * ``SUCCESS``       → non-``None`` dict that passes full validation.
        * ``PARTIAL``       → non-``None`` when ``allow_partial_repair=True``;
                              ``None`` when ``allow_partial_repair=False``.
        * ``FAILED``        → always ``None``.
        * ``ALREADY_VALID`` → the original input (no repair was needed).

        **Always ``None`` under ``RepairMode.SHADOW``**, whatever the status:
        shadow withholds the repair, so a caller that pipes this field into
        production gets nothing rather than silently getting mutated data.
        The payload is on ``proposed_output`` instead.
    proposed_output:
        What ``repaired_output`` *would* have carried had the run been in
        ``AUTO`` — set only under ``RepairMode.SHADOW``, and ``None`` in
        ``AUTO`` (where the payload was committed and lives on
        ``repaired_output``).

        The two fields are never both populated, so exactly one of them
        answers "what did the engine decide the payload should be" and the
        choice of field answers "was it committed".  Rehydrated by the
        adapter identically to ``repaired_output``, so flipping a deployment
        from ``SHADOW`` to ``AUTO`` changes which field carries the value and
        nothing about the value itself.
    mode:
        The ``RepairMode`` this result was produced under.  Recorded so that
        an audit trail, a telemetry consumer, or a log reader can tell a
        committed repair from a withheld one — the operation-level records
        are otherwise identical, because in both modes the engine really does
        apply the operations to its own working copy.
    repaired_at:
        UTC timestamp, auto-set at construction.

    Convenience properties
    ----------------------
    ``is_success``, ``is_partial``, ``is_failed``, ``is_already_valid`` —
    boolean shorthands for the four ``RepairStatus`` values.

    Reading it
    ----------
    ``field_decisions()`` answers "what happened to each field", ``explain()``
    renders that as value-free text safe to log, and ``to_dict()`` is the
    whole record as JSON-ready data.  All three are derived from the fields
    above; see ``stateguard.core.explain``.
    """

    # Required
    status: RepairStatus
    original_input: Any
    initial_violations: list[ContractViolation]
    remaining_violations: list[ContractViolation]
    attempts: list[RepairAttempt]
    repair_log: list[RepairLogEntry]
    contract_id: str

    # Optional / auto-generated
    repaired_output: dict[str, Any] | None = None
    proposed_output: dict[str, Any] | None = None
    mode: RepairMode = RepairMode.AUTO
    ambiguous: list[AmbiguousRepair] = field(default_factory=list)
    repaired_at: datetime = field(default_factory=lambda: datetime.now(tz=UTC))

    # ------------------------------------------------------------------
    # Convenience properties
    # ------------------------------------------------------------------

    @property
    def is_success(self) -> bool:
        """``True`` when ``status`` is ``RepairStatus.SUCCESS``."""
        return self.status is RepairStatus.SUCCESS

    @property
    def is_partial(self) -> bool:
        """``True`` when ``status`` is ``RepairStatus.PARTIAL``."""
        return self.status is RepairStatus.PARTIAL

    @property
    def is_failed(self) -> bool:
        """``True`` when ``status`` is ``RepairStatus.FAILED``."""
        return self.status is RepairStatus.FAILED

    @property
    def is_already_valid(self) -> bool:
        """``True`` when ``status`` is ``RepairStatus.ALREADY_VALID``."""
        return self.status is RepairStatus.ALREADY_VALID

    @property
    def is_ambiguous(self) -> bool:
        """``True`` when ``status`` is ``RepairStatus.AMBIGUOUS``."""
        return self.status is RepairStatus.AMBIGUOUS

    @property
    def is_shadow(self) -> bool:
        """
        ``True`` when this run withheld its repair rather than committing it.

        Deliberately reports the *mode*, not whether ``proposed_output`` is
        populated: a shadow run that found nothing to repair is still a shadow
        run, and a caller checking "was anything committed" needs an answer
        that does not depend on whether the payload happened to be broken.
        """
        return self.mode is RepairMode.SHADOW

    @property
    def has_ambiguous_repairs(self) -> bool:
        """
        ``True`` when any proposal landed in the abstain band.

        Distinct from :attr:`is_ambiguous`: a run can abstain on one field and
        still repair another, ending ``SUCCESS`` or ``PARTIAL`` while carrying
        candidates worth surfacing.
        """
        return bool(self.ambiguous)

    # ------------------------------------------------------------------
    # Reading the result
    # ------------------------------------------------------------------

    def field_decisions(self) -> list[FieldDecision]:
        """
        What happened to each field: repaired, held, discarded, or unresolved.

        See ``stateguard.core.explain.field_decisions``.
        """
        from stateguard.core.explain import field_decisions  # noqa: PLC0415

        return field_decisions(self)

    def explain(self) -> str:
        """
        A short, deterministic, value-free explanation -- safe to log.

        See ``stateguard.core.explain.explain_result``.
        """
        from stateguard.core.explain import explain_result  # noqa: PLC0415

        return explain_result(self)

    def to_dict(self) -> dict[str, Any]:
        """
        The complete record as JSON-ready data, payloads included.

        See ``stateguard.core.explain.result_to_dict``.
        """
        from stateguard.core.explain import result_to_dict  # noqa: PLC0415

        return result_to_dict(self)
