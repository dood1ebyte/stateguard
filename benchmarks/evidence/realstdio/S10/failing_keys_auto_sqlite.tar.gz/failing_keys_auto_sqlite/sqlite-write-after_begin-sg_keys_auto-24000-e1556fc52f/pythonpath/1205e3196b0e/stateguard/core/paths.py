"""
Dot-notation payload navigation.

``FieldSpec.path`` addresses nested fields with dots (``"address.city"``), so
every strategy and the engine need the same answer to "what is at this path,
and is anything there at all".

The distinction that matters is between **absent** and **present but
``None``** — a field explicitly set to ``null`` is not a missing field, and a
repair that conflates the two either overwrites a deliberate ``null`` or
skips a field that needs filling.  ``NOT_FOUND`` is the sentinel that keeps
them apart; ``None`` cannot, because it is a legitimate value.

Shared rather than copied because the sentinel only works if there is exactly
one of it: two modules each defining their own ``_NotFound`` produce values
that are never ``is``-equal across a module boundary, so a helper returning
one module's sentinel silently reads as a real value to the other.

Zero dependencies — part of Layer 0.
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "ELEMENT_OPEN",
    "MAX_PAYLOAD_DEPTH",
    "NOT_FOUND",
    "addresses_array_element",
    "element_path",
    "get_nested_value",
    "nests_deeper_than",
]


class _NotFound:
    """Sentinel distinguishing 'path does not exist' from a value of ``None``."""

    _instance: _NotFound | None = None

    def __new__(cls) -> _NotFound:
        # A single instance, so ``is NOT_FOUND`` holds even if a caller
        # constructs one rather than importing the module-level sentinel.
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self) -> str:
        return "NOT_FOUND"

    def __bool__(self) -> bool:
        # Truthiness is the one test that must never be used on this object.
        # Falsy would alias it to ``0``, ``""``, ``[]`` and ``None`` -- the
        # exact conflation the sentinel exists to prevent -- and truthy would
        # make "nothing here" read as a value. Raising forces the ``is``
        # comparison that is always correct.
        raise TypeError(
            "NOT_FOUND has no truth value; compare with 'is NOT_FOUND' instead. "
            "Truthiness would conflate an absent path with a present 0, '', [] or None."
        )


NOT_FOUND = _NotFound()


def get_nested_value(data: Any, path: str) -> Any:
    """
    Return the value at dot-notation *path* within *data*, or ``NOT_FOUND``.

    ``NOT_FOUND`` is returned when any segment is absent or when an
    intermediate value is not a ``dict`` (a scalar cannot be descended into).
    A present value of ``None`` is returned as ``None``.
    """
    current: Any = data
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return NOT_FOUND
        current = current[part]
    return current


#: Opens an array index in a violation path: ``files[0].path``.
ELEMENT_OPEN = "["


def element_path(array_path: str, index: int) -> str:
    """The path of element *index* of the array at *array_path*: ``files[0]``."""
    return f"{array_path}{ELEMENT_OPEN}{index}]"


def addresses_array_element(path: str) -> bool:
    """
    Whether *path* points inside an array element (``files[0].path``).

    Such paths are for *reporting*: the validator checks array elements
    against their item contract and says where an element is wrong, but no
    repair strategy addresses a path through a list, so the engine never
    hands these violations to one. Property names containing ``[`` are
    refused at extraction, so the marker is unambiguous.
    """
    return ELEMENT_OPEN in path


#: Deepest payload the engine will walk. The same 100 that bounds schema
#: resolution (``RefResolver``) and JSON-string parsing (``coerce``): far past
#: any real tool call -- an MCP arguments object is two or three levels deep --
#: and well inside the interpreter's recursion limit.
MAX_PAYLOAD_DEPTH = 100


def nests_deeper_than(value: Any, limit: int) -> bool:
    """
    Whether *value* contains objects or arrays nested more than *limit* deep.

    Iterative, so it cannot itself overflow the stack it is protecting. The
    payload arrives from a model -- or from whoever controls the client --
    and ``json.loads`` happily produces nesting a few thousand levels deep,
    which ``copy.deepcopy`` and every recursive walk then turn into an
    unhandled ``RecursionError``.
    """
    stack: list[tuple[Any, int]] = [(value, 1)]
    while stack:
        node, depth = stack.pop()
        if isinstance(node, dict):
            children: Any = node.values()
        elif isinstance(node, (list, tuple)):
            children = node
        else:
            continue
        if depth > limit:
            return True
        stack.extend((child, depth + 1) for child in children)
    return False
